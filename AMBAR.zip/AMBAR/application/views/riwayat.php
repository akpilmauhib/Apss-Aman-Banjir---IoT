<div class="card">
    <div class="card-header">
        <div>
            <button><a href="#" class="d-block">Cetak PDF</a></button>
        </div>
    </div>
    <!-- /.card-header -->
    <div class="card-body">
        <table id="example1" class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Waktu</th>
                    <th>Curah Hujan</th>
                    <th>Aliran Air</th>
                    <th>Tinggi Air</th>
                    <th>Keterangan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $no = 1;
                foreach ($riwayat as $data) :
                ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td><?= $data->datenow ?></td>
                        <td><?= $data->curah_hujan ?></td>
                        <td><?= $data->aliran_air ?></td>
                        <td><?= $data->tinggi_air ?></td>
                        <td><?= $data->keterangan ?></td>
                    </tr>
                <?php
                endforeach;
                ?>
            </tbody>
        </table>
    </div>
    <!-- /.card-body -->
</div>